package domain;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Booking {
	@Id
	private String id;
	private Driver driver;
	private Traveler traveler;
	private Ride ride;
	private int dineroBloqueado;
	private int plazas;
	
	public Booking(Driver driver, Traveler traveler, Ride ride, int dineroBloqueado, int plazas) {
		super();
		this.id = ride.getRideNumber() + traveler.getEmail();
		this.driver = driver;
		this.traveler = traveler;
		this.ride = ride;
		this.dineroBloqueado = dineroBloqueado;
		this.plazas = plazas;
	}
	
	
	@Override
	public String toString() {
		return traveler.getName() + " - "+ ride.toString() +" - "+ plazas;
	}


	/**
	 * @return the eserlekuKop
	 */
	public int getPlazas() {
		return plazas;
	}


	/**
	 * @param plazasC the eserlekuKop to set
	 */
	public void setPlazas(int plazasC) {
		this.plazas = plazasC;
	}


	/**
	 * @return the driver
	 */
	public Driver getDriver() {
		return driver;
	}
	/**
	 * @param driver the driver to set
	 */
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	/**
	 * @return the traveler
	 */
	public Traveler getTraveler() {
		return traveler;
	}
	/**
	 * @param traveler the traveler to set
	 */
	public void setTraveler(Traveler traveler) {
		this.traveler = traveler;
	}
	/**
	 * @return the ride
	 */
	public Ride getRide() {
		return ride;
	}
	/**
	 * @param ride the ride to set
	 */
	public void setRide(Ride ride) {
		this.ride = ride;
	}
	/**
	 * @return the diruBlokeatua
	 */
	public int getDineroBloqueado() {
		return dineroBloqueado;
	}
	/**
	 * @param dineroBloqueadop the diruBlokeatua to set
	 */
	public void setDineroBloqueado(int dineroBloqueadop) {
		this.dineroBloqueado = dineroBloqueadop;
	}
	
	
	
}
