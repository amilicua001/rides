package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.*;

import java.awt.GridLayout;
import java.awt.List;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class BookRideGUI extends JFrame {

	private JPanel PanelReserva;
	private JTextField NotesField;
	private JTextField NoteTitle;
	private JTextField SeatTitle;
	private JComboBox<Integer> SeatList;
	private JTextField Departure;
	private JTextField Arrive;
	private JTextField Date;
	private JTextField PrecioTitle;
	private JTextField Precio;
	private JButton jButtonClose;
	private JLabel lblError;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookRideGUI frame = new BookRideGUI(null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookRideGUI(Ride ride, User user) {
		setTitle(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.title")); //$NON-NLS-1$ //$NON-NLS-2$
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 339);
		PanelReserva = new JPanel();
		PanelReserva.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(PanelReserva);
		PanelReserva.setLayout(null);
		
		JButton btnReservar = new JButton();
		btnReservar.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.Erreserbatu"));
		btnReservar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int nPlazas = (int) SeatList.getSelectedItem();
				Booking reserva = new Booking(ride.getDriver(), (Traveler) user, ride, (int)ride.getPrice() * nPlazas, nPlazas);
				
				BLFacade facade = MainGUI.getBusinessLogic(); 
				Boolean guardado = facade.guardarReserva(reserva);
				
				if(guardado) {
					lblError.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.gordeDa"));
				}else {
					lblError.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.EzDaGorde"));
				}
			}
		});
		btnReservar.setBounds(75, 202, 126, 51);
		PanelReserva.add(btnReservar);
		
		NotesField = new JTextField();
		NotesField.setBounds(33, 131, 378, 63);
		PanelReserva.add(NotesField);
		NotesField.setColumns(10);
		
		NoteTitle = new JTextField();
		NoteTitle.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.OharraTitle"));
		NoteTitle.setEditable(false);
		NoteTitle.setBounds(33, 102, 96, 19);
		PanelReserva.add(NoteTitle);
		NoteTitle.setColumns(10);
		
		
		
		SeatTitle = new JTextField();
		SeatTitle.setEnabled(true);
		SeatTitle.setEditable(false);
		SeatTitle.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.EserlekuTitle"));
		SeatTitle.setBounds(33, 71, 125, 21);
		PanelReserva.add(SeatTitle);
		SeatTitle.setColumns(10);
		
		Departure = new JTextField();
		Departure.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.Irteera") + ": " + ride.getFrom());
		Departure.setEditable(false);
		Departure.setBounds(47, 10, 153, 19);
		PanelReserva.add(Departure);
		Departure.setColumns(10);
		
		Arrive = new JTextField();
		Arrive.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.Helmuga") + ": " + ride.getTo());
		Arrive.setEditable(false);
		Arrive.setBounds(242, 10, 156, 19);
		PanelReserva.add(Arrive);
		Arrive.setColumns(10);
		
		Date = new JTextField();
		Date.setEditable(false);
		Date.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.Data") + ": " + ride.getDate());
		Date.setBounds(252, 39, 146, 19);
		PanelReserva.add(Date);
		Date.setColumns(10);

		PrecioTitle = new JTextField();
		PrecioTitle.setText(ResourceBundle.getBundle("Etiquetas").getString("BookRideGUI.PrezioaTitle"));
		PrecioTitle.setEditable(false);
		PrecioTitle.setBounds(33, 39, 125, 19);
		PanelReserva.add(PrecioTitle);
		PrecioTitle.setColumns(10);
		
		Precio = new JTextField();
		Precio.setText(String.valueOf(ride.getPrice()));
		Precio.setEditable(false);
		Precio.setBounds(183, 39, 40, 19);
		PanelReserva.add(Precio);
		Precio.setColumns(10);
		
		
		ArrayList<Integer> nPlazas = new ArrayList();
		for(int i=1; i<=(int)ride.getnPlaces(); i++) {
			nPlazas.add(i);
		}
		DefaultComboBoxModel<Integer> comboBoxModel = new DefaultComboBoxModel(nPlazas.toArray());
        SeatList = new JComboBox<>(comboBoxModel);
		SeatList.setBounds(183, 71, 46, 21);
		PanelReserva.add(SeatList);
		
		jButtonClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("Close")); //$NON-NLS-1$ //$NON-NLS-2$
		jButtonClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jButtonClose_actionPerformed(e);
			}
		});
		jButtonClose.setBounds(225, 202, 146, 51);
		PanelReserva.add(jButtonClose);
		
		lblError = new JLabel(""); //$NON-NLS-1$ //$NON-NLS-2$
		lblError.setBounds(36, 263, 335, 29);
		PanelReserva.add(lblError);

	}
	private void jButtonClose_actionPerformed(ActionEvent e) {
		this.setVisible(false);
	}
}
