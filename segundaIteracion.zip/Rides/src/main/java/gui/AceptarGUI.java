package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Booking;
import domain.Driver;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JLabel;

public class AceptarGUI extends JFrame {

	private JPanel contentPane;

	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AceptarGUI frame = new AceptarGUI(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AceptarGUI(Driver driver) {
		setTitle(ResourceBundle.getBundle("Etiquetas").getString("OnartuGUI.title")); //$NON-NLS-1$ //$NON-NLS-2$
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		
       
        
        BLFacade facade = MainGUI.getBusinessLogic(); 
        ArrayList<Booking> BookingList = facade.getBookingList(driver);
        
        DefaultComboBoxModel<Booking> comboBoxModel = new DefaultComboBoxModel(BookingList.toArray());
		contentPane.setLayout(null);
		JComboBox comboBox = new JComboBox(comboBoxModel);
		comboBox.setBounds(10, 58, 416, 31);
		contentPane.add(comboBox);
		
		JButton btnRechazar = new JButton(ResourceBundle.getBundle("Etiquetas").getString("OnartuGUI.Deuseztatu"));
		btnRechazar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				facade.rechazar((Booking)comboBox.getSelectedItem());
			}
			
		});
		btnRechazar.setBounds(54, 146, 125, 46);
		contentPane.add(btnRechazar);
		
		JButton btnAceptar = new JButton(ResourceBundle.getBundle("Etiquetas").getString("OnartuGUI.Onartu"));
		btnAceptar.setBounds(265, 146, 125, 46);
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				facade.aceptar((Booking)comboBox.getSelectedItem());
			}
		});
		contentPane.add(btnAceptar);
		
		JButton btnClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("Close"));
		btnClose.setBounds(160, 212, 125, 41);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonClose_actionPerformed(e);
			}
		});
		contentPane.add(btnClose);
	}
	private void jButtonClose_actionPerformed(ActionEvent e) {
		this.setVisible(false);
}
}
