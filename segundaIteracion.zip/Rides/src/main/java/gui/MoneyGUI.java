package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Driver;
import domain.User;

import java.awt.GridLayout;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MoneyGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final JTextField errorField = new JTextField();
	private JTextField cuenta;
	private JTextField changeText;


	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MoneyGUI frame = new MoneyGUI(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MoneyGUI(User user) {
		setTitle(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.this.title")); //$NON-NLS-1$ //$NON-NLS-2$
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		cuenta = new JTextField();
		cuenta.setEditable(false);
		cuenta.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Saldo")+user.getMoney()); //$NON-NLS-1$ //$NON-NLS-2$
		contentPane.add(cuenta);
		cuenta.setColumns(10);
		
		changeText = new JTextField();
		changeText.setText(""); //$NON-NLS-1$ //$NON-NLS-2$
		contentPane.add(changeText);
		changeText.setColumns(10);
		
		JPanel panel = new JPanel();
		contentPane.add(panel);
		
		JButton btnDeposit = new JButton(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Deposit")); //$NON-NLS-1$ //$NON-NLS-2$
		btnDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try { 
					errorField.setText(""); //$NON-NLS-1$ //$NON-NLS-2$
					int cantidad = Integer.parseInt(changeText.getText());
					
					if(cantidad <= 0) {
						
						errorField.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.EzNaturala")); //$NON-NLS-1$ //$NON-NLS-2$
						
					}else {
						BLFacade facade = MainGUI.getBusinessLogic();
						facade.ingresarDinero(user, cantidad);
						
						cuenta.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Saldo")+saldo(user, facade)); //Kontuko dirua aldatu ondoren zein den erakutsi
						user.setMoney(saldo(user, facade));
					}
				}catch (Exception err){
					errorField.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.EzNaturala")); //$NON-NLS-1$ //$NON-NLS-2$
					
				}

				
			}
		});
		panel.add(btnDeposit);
		
		JButton btnWithdraw = new JButton(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Withdraw")); //$NON-NLS-1$ //$NON-NLS-2$
		btnWithdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try { 
					errorField.setText(""); //$NON-NLS-1$ //$NON-NLS-2$
					int cantidad = Integer.parseInt(changeText.getText());
					BLFacade facade = MainGUI.getBusinessLogic();
					if(cantidad <= 0 || cantidad> saldo(user,facade)) {
						//ERRORE MEZUA
						errorField.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Big")); //$NON-NLS-1$ //$NON-NLS-2$
						
					}else {
						
						facade.retirarDinero(user, cantidad);
						
						cuenta.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.Saldo")+saldo(user, facade)); //Kontuko dirua aldatu ondoren zein den erakutsi
						user.setMoney(saldo(user, facade));
					}
				}catch (Exception err){
					errorField.setText(ResourceBundle.getBundle("Etiquetas").getString("MoneyGUI.EzNaturala")); //$NON-NLS-1$ //$NON-NLS-2$
					
				}

				
			}
		});
		panel.add(btnWithdraw);
		
		errorField.setEditable(false);
		errorField.setText(""); //$NON-NLS-1$ //$NON-NLS-2$
		contentPane.add(errorField);
		errorField.setColumns(10);
		
		JButton jButtonClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("Close")); //$NON-NLS-1$ //$NON-NLS-2$
		jButtonClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jButtonClose_actionPerformed(e);
			}
		});
		contentPane.add(jButtonClose);
	}
	
	private void jButtonClose_actionPerformed(ActionEvent e) {
		this.setVisible(false);
	}
	
	public int saldo (User user, BLFacade facade) {
		return facade.saldo(user);
	}
}

